
# Forklift Driver – Android 0.1

Ensimmäinen oikea Android-projekti.

Ominaisuudet:
- Pystykuva
- Isometrinen varasto
- Touchpad-ohjaus ruudun alaosassa
- Volume Up = haarukat ylös
- Volume Down = haarukat alas
- Lava A-03
- Rekan lastausalue
- Tehtävän suorittaminen ja onnistumisruutu

## Android Studio

Avaa tämä kansio Android Studiossa ja anna Gradlen synkronoida projekti.
Sen jälkeen Run ▶ app valitulla Android-puhelimella/emulaattorilla.

Huom: fyysiset volume-näppäimet kaapataan pelin käyttöön tässä prototyypissä, joten ne eivät säädä mediasäätimen äänenvoimakkuutta pelin aikana.
