
package fi.forkliftdriver

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

class ForkliftGameView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var lastTime = System.nanoTime()
    private var moveX = 0f
    private var moveY = 0f
    private var padActive = false

    private var tx = 0f
    private var ty = 2.0f
    private var angle = 0f
    private var speed = 0f
    private var forks = 0f
    private var hasPallet = false
    private var completed = false
    private var elapsed = 0f

    private val palletX = -2.0f
    private val palletY = -1.7f
    private val dockX = 2.3f
    private val dockY = -1.0f

    init { setLayerType(View.LAYER_TYPE_SOFTWARE, null) }

    fun lift(amount: Float) {
        forks = (forks + amount).coerceIn(0f, 1f)
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val padTop = height * 0.69f
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                if (e.y >= padTop) {
                    padActive = true
                    updatePad(e.x, e.y, padTop)
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (padActive) updatePad(e.x, e.y, padTop)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL, MotionEvent.ACTION_POINTER_UP -> {
                padActive = false
                moveX = 0f
                moveY = 0f
                return true
            }
        }
        return true
    }

    private fun updatePad(x: Float, y: Float, top: Float) {
        val cx = width / 2f
        val cy = top + (height - top) / 2f
        val dx = x - cx
        val dy = y - cy
        val max = min(width * .42f, (height - top) * .36f)
        val len = max(1f, hypot(dx, dy))
        val k = min(1f, max / len)
        moveX = dx * k / max
        moveY = -dy * k / max
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val now = System.nanoTime()
        val dt = min(0.035f, (now - lastTime) / 1_000_000_000f)
        lastTime = now

        if (!completed) {
            elapsed += dt
            speed += moveY * dt * 3.2f
            speed *= exp((-5.0f * dt).toDouble()).toFloat()
            angle += moveX * dt * 1.9f
            tx += sin(angle) * speed * dt * 2.1f
            ty += -cos(angle) * speed * dt * 2.1f
            tx = tx.coerceIn(-5.3f, 5.3f)
            ty = ty.coerceIn(-4.0f, 4.5f)

            val d = hypot(tx - palletX, ty - palletY)
            if (!hasPallet && d < 0.95f && forks > .70f) hasPallet = true

            if (hasPallet && tx in 1.7f..4.5f && ty in -2.0f..1.0f && forks > .35f) {
                completed = true
            }
        }

        drawWorld(c)
        drawHud(c)
        drawTouchpad(c)

        if (completed) drawComplete(c)
        postInvalidateOnAnimation()
    }

    private fun iso(x: Float, y: Float): PointF {
        val s = min(width, height) * .070f
        return PointF(width * .5f + (x - y) * s, height * .31f + (x + y) * s * .50f)
    }

    private fun poly(c: Canvas, pts: List<PointF>, color: Int, stroke: Int? = null) {
        val p = Path()
        p.moveTo(pts[0].x, pts[0].y)
        for (i in 1 until pts.size) p.lineTo(pts[i].x, pts[i].y)
        p.close()
        paint.style = Paint.Style.FILL
        paint.color = color
        c.drawPath(p, paint)
        if (stroke != null) {
            paint.style = Paint.Style.STROKE
            paint.color = stroke
            paint.strokeWidth = 1f
            c.drawPath(p, paint)
            paint.style = Paint.Style.FILL
        }
    }

    private fun box(c: Canvas, x: Float, y: Float, w: Float, h: Float, z: Float, color: Int) {
        val a = iso(x,y); val b = iso(x+w,y); val d = iso(x,y+h); val e = iso(x+w,y+h)
        val dz = z * min(width,height) * .070f
        poly(c, listOf(a,b,PointF(e.x,e.y-dz),PointF(d.x,d.y-dz)), color)
        poly(c, listOf(d,e,PointF(e.x,e.y-dz),PointF(d.x,d.y-dz)), Color.rgb(92,83,70))
    }

    private fun drawWorld(c: Canvas) {
        c.drawColor(Color.rgb(176,166,148))
        for (x in -8..8) for (y in -6..7) {
            val a=iso(x.toFloat(),y.toFloat()); val b=iso(x+1f,y.toFloat())
            val d=iso(x.toFloat(),y+1f); val e=iso(x+1f,y+1f)
            poly(c, listOf(a,b,e,d), if ((x+y)%2==0) Color.rgb(183,173,156) else Color.rgb(169,159,143), Color.rgb(150,140,124))
        }

        box(c, 1.0f,-2.0f,3.9f,2.8f,.02f,Color.rgb(222,180,38))
        box(c, 1.25f,-1.75f,3.4f,2.3f,.03f,Color.rgb(102,97,87))

        val racks = listOf(floatArrayOf(-4f,-2.7f),floatArrayOf(-4f,-.4f),floatArrayOf(-4f,1.9f))
        racks.forEachIndexed { i,r ->
            box(c,r[0],r[1],2.2f,1.0f,.15f,Color.rgb(39,57,75))
            for (j in 0..2) {
                box(c,r[0]+.15f,r[1]+.08f,1.9f,.18f,.35f+j*.38f,Color.rgb(185,105,45))
                box(c,r[0]+.35f,r[1]+.1f,.72f,.62f,.45f+j*.38f,Color.rgb(198,140,84))
            }
            label(c, "A-0${i+1}", iso(r[0]+.7f,r[1]+.02f), 14f, Color.BLACK)
        }

        box(c,palletX,palletY,1f,.72f,.22f, if(hasPallet) Color.rgb(110,88,65) else Color.rgb(214,157,84))
        if (!hasPallet) {
            val p=iso(palletX+.18f,palletY+.08f)
            label(c,"A-03",PointF(p.x,p.y-30f),15f,Color.rgb(70,50,25))
        }

        box(c,dockX,dockY,3.2f,1.65f,.03f,Color.rgb(205,207,210))
        box(c,dockX+2.0f,dockY-.25f,1.05f,2.15f,.15f,Color.rgb(195,45,43))

        drawForklift(c)
    }

    private fun drawForklift(c: Canvas) {
        val p=iso(tx,ty)
        c.save()
        c.translate(p.x,p.y)
        c.rotate(-angle*20f)
        paint.color=Color.rgb(240,165,28); c.drawRect(-27f,-18f,27f,12f,paint)
        paint.color=Color.rgb(35,38,40); c.drawRect(-10f,-34f,18f,-16f,paint)
        paint.color=Color.BLACK; c.drawRect(-30f,6f,-15f,17f,paint); c.drawRect(14f,6f,29f,17f,paint)
        paint.strokeWidth=6f; paint.color=Color.rgb(25,25,25); c.drawLine(21f,-22f,21f,-63f,paint)
        paint.color=Color.rgb(235,165,25); c.drawLine(18f,-59f,51f,-59f,paint)
        if(hasPallet){paint.color=Color.rgb(198,140,84);c.drawRect(27f,-74f,54f,-60f,paint)}
        c.restore()
    }

    private fun drawHud(c: Canvas) {
        rounded(c,14f,14f,310f,82f,18f,0xCC121212.toInt())
        label(c,"Tehtävä 001",30f,40f,18f,Color.WHITE)
        label(c,"Hae lava A-03 ja lastaa se rekkaan.",30f,67f,14f,Color.LTGRAY)
        rounded(c,width-170f,14f,width-14f,62f,14f,0xCC121212.toInt())
        val sec=elapsed.toInt()
        label(c,String.format("%02d:%02d",sec/60,sec%60),width-150f,45f,18f,Color.WHITE)
        label(c,"Haarukat ${"%d".format((forks*100).toInt())}%",width-150f,66f,11f,Color.LTGRAY)
        rounded(c,width-78f,76f,width-14f,140f,14f,0xCC121212.toInt())
        label(c,"▲",width-46f,116f,25f,Color.WHITE)
        rounded(c,width-78f,148f,width-14f,212f,14f,0xCC121212.toInt())
        label(c,"▼",width-46f,188f,25f,Color.WHITE)
    }

    private fun drawTouchpad(c: Canvas) {
        val top=height*.69f
        rounded(c,14f,top,width-14f,height-14f,24f,0x66111111)
        paint.style=Paint.Style.STROKE;paint.strokeWidth=2f;paint.color=0x55FFFFFF
        c.drawRoundRect(14f,top,width-14f,height-14f,24f,24f,paint);paint.style=Paint.Style.FILL
        val cx=width/2f;val cy=top+(height-top)/2f
        paint.color=0x55FFFFFF
        c.drawCircle(cx,cy,41f,paint)
        label(c,"TOUCHPAD",cx-40f,cy-60f,11f,0x88FFFFFF.toInt())
        label(c,"Vedä peukalolla haluamaasi suuntaan",cx-105f,height-30f,10f,0x66FFFFFF.toInt())
    }

    private fun drawComplete(c: Canvas) {
        paint.color=0xAA000000.toInt();c.drawRect(0f,0f,width.toFloat(),height.toFloat(),paint)
        rounded(c,width*.12f,height*.39f,width*.88f,height*.61f,24f,Color.rgb(30,30,30))
        label(c,"TOIMITUS ONNISTUI!",width*.25f,height*.47f,22f,Color.WHITE)
        label(c,"Aika ${String.format("%02d:%02d",elapsed.toInt()/60,elapsed.toInt()%60)}  •  Vahinkoja 0",width*.22f,height*.53f,14f,Color.LTGRAY)
    }

    private fun rounded(c:Canvas,l:Float,t:Float,r:Float,b:Float,rad:Float,color:Int){
        paint.color=color;paint.style=Paint.Style.FILL;c.drawRoundRect(l,t,r,b,rad,rad,paint)
    }
    private fun label(c:Canvas,s:String,x:Float,y:Float,size:Float,color:Int){
        paint.color=color;paint.textSize=size;paint.typeface=Typeface.create("sans",Typeface.BOLD);paint.textAlign=Paint.Align.LEFT
        c.drawText(s,x,y,paint)
    }
}
